CREATE DATABASE Tournamet
GO

USE Tournamet
GO

CREATE TABLE "User"(
ClientID int NOT NULL,
"Login" nvarchar(20) NOT NULL,
"Password" nvarchar(30)NOT NULL,
"Name" nvarchar(30)NOT NULL,
Surname nvarchar(30)NOT NULL,
"status" nvarchar(30)NOT NULL,
PRIMARY KEY (ClientID)
)
GO

CREATE TABLE Discplines(
DisID int NOT NULL,
DisName nvarchar(30) NOT NULL,
PRIMARY KEY (DisID)
)
GO
CREATE TABLE tournamenst(
TournamentID int NOT NULL,
TournamentName nvarchar(30) NOT NULL,
PRIMARY KEY (TournamentID)
)
GO
CREATE TABLE Sponsors(
SponsorID int NOT NULL,
SponsorName nvarchar(30) NOT NULL,
tournamentid int not null,
DonationAmount int NOT NULL,
PRIMARY KEY (SponsorID),
FOREIGN KEY(tournamentid) REFERENCES tournamenst(TournamentID)
)
GO
CREATE TABLE Teams(
TeamID int NOT NULL,
TeamName nvarchar(30) NOT NULL,
PRIMARY KEY (TeamID)
)
GO

CREATE TABLE "Table"(
turnamentsID int NOT NULL,
dispnameid  int NOT NULL,
dateandtimeofstart date NOT NULL,
dateandtimeofend date NOT NULL,
winningprize int not null,
PRIMARY KEY (turnamentsID),
FOREIGN KEY(dispnameid) REFERENCES Discplines(DisID),
FOREIGN KEY(dispnameid) REFERENCES Discplines(DisID)
)
GO
INSERT "User"
(ClientID,"Login", "Password", "Name", Surname,"status") 
VALUES
(1, 'Admin', 'admin1','������','������','Admin'), 
(2, 'Parimatch', 'Parimatch1','����','������','�������'), 
(3, '1xbet', 'xbet1','��������','�������','�������'),  
(4, 'Soulmor', 'soulmor1','����','�����','�����')


INSERT Discplines
(DisID, DisName)
VALUES
(1, 'Dota2'),
(2, 'CS GO'),
(3, 'LoL'),
(4, 'Point Black')
INSERT tournamenst
(TournamentID, TournamentName)
VALUES
(1,'esl'),
(2,'internation'),
(3,'major')

INSERT Teams
(TeamID, TeamName)
VALUES
(1, 'Team Liquid'),
(2, 'NaVi'),
(3, 'Virtus.Pro')

INSERT Sponsors
(SponsorID, SponsorName,tournamentid,DonationAmount)
VALUES
(1, 'parimatch',1,'20000'),
(2, '1xbet',2,'20000'),
(3, 'razer',3,'20000')



INSERT "Table"
(turnamentsID, dispnameid,dateandtimeofstart,dateandtimeofend,winningprize)
VALUES
(1, 2,'12.07.2020','12.08.2020','40000'),
(2, 1,'22.03.2020','23.04.2020','1000000'),
(3, 1,'14.05.2020','14.06.2020','20000')