﻿
using project.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.Interfaces;
using project.data.Interfaces;
using project.data.Models;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tournamentController : ControllerBase
    {
        private readonly IUnitOfWork UnitOfWork;

        public tournamentController(IUnitOfWork UnitOfWork)
        {
            this.UnitOfWork = UnitOfWork ?? throw new ArgumentNullException(nameof(UnitOfWork));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<tournamenst>>> GetT()
        {
            return Ok(await UnitOfWork.Tournament.Get());
        }
        [HttpPost]
        public async Task<ActionResult> CreateT(tournamenst user)
        {
            await UnitOfWork.Tournament.Add(user);
            await UnitOfWork.Complete();
            return NoContent();
        }
        [HttpGet("{TournamentID}")]
        public async Task<ActionResult<IEnumerable<tournamenst>>> GetT(int TournamentID)
        {
            return Ok(await UnitOfWork.Tournament.GetById(TournamentID));
        }
        [HttpDelete("{TournamentID}")]
        public async Task<ActionResult<IEnumerable<tournamenst>>> DeleteT(int TournamentID)
        {

            await UnitOfWork.Tournament.Delete(TournamentID);
            await UnitOfWork.Complete();
            return NoContent();

        }
    }
}
