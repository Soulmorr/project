﻿
using project.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.Interfaces;
using project.data.Interfaces;
using project.data.Models;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamsController : ControllerBase
    {
        private readonly IUnitOfWork UnitOfWork;

        public TeamsController(IUnitOfWork UnitOfWork)
        {
            this.UnitOfWork = UnitOfWork ?? throw new ArgumentNullException(nameof(UnitOfWork));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Teams>>> GetT()
        {
            return Ok(await UnitOfWork.Team.Get());
        }
        [HttpPost]
        public async Task<ActionResult> CreateT(Teams user)
        {
            await UnitOfWork.Team.Add(user);
            await UnitOfWork.Complete();
            return NoContent();
        }
        [HttpGet("{ClientID}")]
        public async Task<ActionResult<IEnumerable<Teams>>> GetT(int ClientID)
        {
            return Ok(await UnitOfWork.Team.GetById(ClientID));
        }
        [HttpDelete("{ClientID}")]
        public async Task<ActionResult<IEnumerable<Teams>>> DeleteT(int ClientID)
        {
            
            await UnitOfWork.Team.Delete(ClientID);
            await UnitOfWork.Complete();
            return NoContent();

        }
    }
}
