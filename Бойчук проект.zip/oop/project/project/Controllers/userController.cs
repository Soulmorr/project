﻿
using project.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.Interfaces;
using project.data.Interfaces;
using project.data.Models;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userController : ControllerBase
    {
        private readonly IUnitOfWork UnitOfWork;

        public userController(IUnitOfWork UnitOfWork)
        {
            this.UnitOfWork = UnitOfWork ?? throw new ArgumentNullException(nameof(UnitOfWork));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetT()
        {
            return Ok(await UnitOfWork.Users.Get());
        }
        [HttpPost]
        public async Task<ActionResult> CreateT(User user)
        {
            await UnitOfWork.Users.Add(user);
            await UnitOfWork.Complete();
            return NoContent();
        }
        [HttpGet("{ClientID}")]
        public async Task<ActionResult<IEnumerable<User>>> GetT(int ClientID)
        {
            return Ok(await UnitOfWork.Users.GetById(ClientID));
        }
        [HttpDelete("{ClientID}")]
        public async Task<ActionResult<IEnumerable<User>>> DeleteT(int ClientID)
        {
            
            await UnitOfWork.Users.Delete(ClientID);
            await UnitOfWork.Complete();
            return NoContent();

        }
    }
}
