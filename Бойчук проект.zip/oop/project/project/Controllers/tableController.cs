﻿
using project.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.Interfaces;
using project.data.Interfaces;
using project.data.Models;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tableController : ControllerBase
    {
        private readonly IUnitOfWork UnitOfWork;

        public tableController(IUnitOfWork UnitOfWork)
        {
            this.UnitOfWork = UnitOfWork ?? throw new ArgumentNullException(nameof(UnitOfWork));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Table>>> GetT()
        {
            return Ok(await UnitOfWork.Table.Get());
        }
        [HttpPost]
        public async Task<ActionResult> CreateT(Table table)
        {
            await UnitOfWork.Table.Add(table);
            await UnitOfWork.Complete();
            return NoContent();
        }
        [HttpGet("{turnamentsID}")]
        public async Task<ActionResult<IEnumerable<Table>>> GetT(int turnamentsID)
        {
            return Ok(await UnitOfWork.Table.GetById(turnamentsID));
        }
        [HttpDelete("{turnamentsID}")]
        public async Task<ActionResult<IEnumerable<Table>>> DeleteT(int turnamentsID)
        {
            
            await UnitOfWork.Table.Delete(turnamentsID);
            await UnitOfWork.Complete();
            return NoContent();

        }
    }
}
