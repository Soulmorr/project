﻿
using project.data.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.Interfaces;
using project.data.Interfaces;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class disController : ControllerBase
    {
        private readonly IUnitOfWork UnitOfWork;

        public disController(IUnitOfWork UnitOfWork)
        {
            this.UnitOfWork = UnitOfWork ?? throw new ArgumentNullException(nameof(UnitOfWork));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Disciplines>>> GetT()
        {
            return Ok(await UnitOfWork.Dis.Get());
        }
        [HttpPost]
        public async Task<ActionResult> CreateT(Disciplines user)
        {
            await UnitOfWork.Dis.Add(user);
            await UnitOfWork.Complete();
            return NoContent();
        }
        [HttpGet("{ClientID}")]
        public async Task<ActionResult<IEnumerable<Disciplines>>> GetT(int ClientID)
        {
            return Ok(await UnitOfWork.Dis.GetById(ClientID));
        }
        [HttpDelete("{ClientID}")]
        public async Task<ActionResult<IEnumerable<Disciplines>>> DeleteT(int ClientID)
        {
            
            await UnitOfWork.Dis.Delete(ClientID);
            await UnitOfWork.Complete();
            return NoContent();

        }
    }
}
