﻿
using project.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.Interfaces;
using project.data.Interfaces;
using project.data.Models;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class sponsorsController : ControllerBase
    {
        private readonly IUnitOfWork UnitOfWork;

        public sponsorsController(IUnitOfWork UnitOfWork)
        {
            this.UnitOfWork = UnitOfWork ?? throw new ArgumentNullException(nameof(UnitOfWork));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Sponsors>>> GetT()
        {
            return Ok(await UnitOfWork.Sponsor.Get());
        }
        [HttpPost]
        public async Task<ActionResult> CreateT(Sponsors user)
        {
            await UnitOfWork.Sponsor.Add(user);
            await UnitOfWork.Complete();
            return NoContent();
        }
        [HttpGet("{ClientID}")]
        public async Task<ActionResult<IEnumerable<Sponsors>>> GetT(int ClientID)
        {
            return Ok(await UnitOfWork.Sponsor.GetById(ClientID));
        }
        [HttpDelete("{ClientID}")]
        public async Task<ActionResult<IEnumerable<Sponsors>>> DeleteT(int ClientID)
        {
            
            await UnitOfWork.Sponsor.Delete(ClientID);
            await UnitOfWork.Complete();
            return NoContent();

        }
    }
}
