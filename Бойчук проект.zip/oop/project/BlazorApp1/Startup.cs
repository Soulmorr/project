using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using BlazorApp1.Data;
//using project.data.Interfaces;
//using project.data.Data;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using AutoMapper;
using project.data.Interfaces;
using project.data.Data;

namespace BlazorApp1
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<ITableService, tableService>();
            services.AddRazorPages();
            services.AddServerSideBlazor();
           
            //services.AddSingleton<ITableService, tableService>();
            services.AddScoped<ValuesRepository>();
            services.AddTransient<ITournamentRep, TournamentRep>();
           services.AddTransient<ITableRep, TableRep>();
            services.AddTransient<IUserRep, UserRep>();
            services.AddTransient<ITeamsRep, TeamRep>();
            services.AddTransient<ITeamservice, teamservice>();
            services.AddTransient<ISponsorsRep, SponsorsRep>();
           services.AddTransient<IDisRep, DisRep>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddAutoMapper(typeof(Startup));
            services.AddDbContext<AplContext>(options =>
            {
                string connectionString = Configuration.GetConnectionString("defaultConnection");
               options.UseSqlServer(connectionString);
           });
            services.AddHttpClient<ITableService, tableService>(client => {
                client.BaseAddress = new Uri("https://localhost:5001/api/Table/");
            });
            services.AddSingleton<HttpClient>();
            services.AddHttpClient<ITeamservice, teamservice>(client => {
                client.BaseAddress = new Uri("https://localhost:5001/api/Teams/");
            });
            services.AddHttpClient<IdisService, disService>(client => {
                client.BaseAddress = new Uri("https://localhost:5001/api/dis/");
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });
        }
    }
}
