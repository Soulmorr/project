﻿


using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace BlazorApp1.Data
{
  
    public interface ITeamservice
    {
         public Task<IEnumerable<Teams>> GetS();

    }
}
