﻿using AutoMapper;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using project.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using Microsoft.AspNetCore.Components;
using project.data.Models;

namespace BlazorApp1.Data
{
    public class disService : IdisService
    {
        public disService(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

        private HttpClient httpClient { get; }

        public async Task<IEnumerable<Disciplines>> GetS()
        {
            return await httpClient.GetJsonAsync<IEnumerable<Disciplines>>("");
        }
    }
}

