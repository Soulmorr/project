﻿using AutoMapper;
using project.data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using project.data.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using Microsoft.AspNetCore.Components;

namespace BlazorApp1.Data
{
    public class teamservice : ITeamservice
    {
        public teamservice(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

        private HttpClient httpClient { get; }

        public async Task<IEnumerable<Teams>> GetS()
        {
            return await httpClient.GetJsonAsync<IEnumerable<Teams>>("");
        }
    }
}

