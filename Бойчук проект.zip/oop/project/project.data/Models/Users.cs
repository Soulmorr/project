﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace project.Models
{
    /// <summary>
    /// class added some properties in identity user
    /// </summary>
    public class Users : IdentityUser
    {
        public string FirsName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDay { get; set; }
        
        
    }
}
