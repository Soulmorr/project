﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Models
{
    public class tournamenst
    {
        public int TournamentID { get; set; }
        public string TournamentName { get; set; }
        
    }
}
