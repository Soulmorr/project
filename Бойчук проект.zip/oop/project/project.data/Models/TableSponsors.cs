﻿using project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Models
{
    public class TableSponsors
    {
        public int SponsorID { get; set; }
        public int TournamentID { get; set; }
        public Sponsors sponsors { get; set; }
        public tournamenst tournamenst { get; set; }
    }
}
