﻿using Microsoft.AspNetCore.Identity;
using project.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace project.data.Models
{
    public class User
    {
        public int ClientID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public bool IsAuthenticated { get; set; }
        
    }
}
