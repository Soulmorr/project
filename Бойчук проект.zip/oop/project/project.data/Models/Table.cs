﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Models
{
    public class Table
    {
        public int turnamentsID { get; set; }
        public int dispnameid { get; set; }
        public DateTime dateandtimeofstart { get; set; }

        public DateTime dateandtimeofend { get; set; }
        public int winningprize { get; set; }
        public List<Sponsors> sponsors { get; set; }
       public Disciplines discipline { get; set; }
   
    }
}
