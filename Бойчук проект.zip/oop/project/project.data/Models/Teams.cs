﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Models
{
    public class Teams
    {
        public int TeamID { get; set; }
        public string TeamName { get; set; }
       
    }
}
