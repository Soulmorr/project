﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Models
{
    public class Disciplines
    {
        public int DisId { get; set; }
        public string DisName { get; set; }
        public List<Table> table { get; set; }
        
    }
}
