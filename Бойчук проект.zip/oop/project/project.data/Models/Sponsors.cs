﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Models
{
    public class Sponsors
    {
        public int SponsorID { get; set; }
        public string SponsorName { get; set; }
        public int tournamentid { get; set; }

        public int DonationAmount { get; set; }
        public List<Table> table { get; set; }
    }
}
