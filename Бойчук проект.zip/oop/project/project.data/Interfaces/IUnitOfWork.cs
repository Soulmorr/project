﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Interfaces
{
    public interface IUnitOfWork
    {
        ITableRep Table { get; }
        IUserRep Users { get; }
        IDisRep Dis { get; }
        ISponsorsRep Sponsor { get; }
        ITeamsRep Team { get; }
        ITournamentRep Tournament { get; }
        Task<int> Complete();
    }
}
