﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace project.data.Interfaces
{
    /// <summary>
    /// Generic interface for CRUD
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IGenericRepository<T> where T : class
    {
        Task<T> Add(T obj);
        Task<IEnumerable<T>> Get();
        Task<T> GetById(int id);
        Task<T> Update(T obj);
        Task<T> Delete(int id);
    }

}
