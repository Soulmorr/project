﻿
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Interfaces
{
    public interface ITournamentRep : IGenericRepository<tournamenst>
    {
    }
}
