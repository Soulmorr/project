﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using project.data.Models;

namespace project.data.Interfaces
{
    public interface IUserRep : IGenericRepository<User>
    {
    }
}
