﻿
using project.data.Interfaces;
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class UserRep : BaseRepository<User>, IUserRep
    {
        public UserRep(AplContext context) : base(context)
        {
        }
    }
}
