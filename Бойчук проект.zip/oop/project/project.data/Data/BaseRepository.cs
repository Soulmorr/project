﻿using project.data.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using project.data.Interfaces;


namespace project.data.Data
{
    /// <summary>
    /// generic repository of the CRUD
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public class BaseRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class
    {
        private readonly AplContext _context;

        public BaseRepository(AplContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public IQueryable<TEntity> FindByCondition(Expression<Func<TEntity, bool>> expression)
        {
            return this._context.Set<TEntity>()
                .Where(expression)
                .AsNoTracking();
        }

        public IQueryable<TEntity> FindAll()
        {
            return _context.Set<TEntity>()
                .AsNoTracking();
        }

        public async Task<TEntity> Add(TEntity obj)
        {
                _context.Set<TEntity>().Add(obj);
                await _context.SaveChangesAsync();
                return obj;
        }

        public async Task<TEntity> Delete(int id)
        {
            var obj = await _context.Set<TEntity>().FindAsync(id);
            if (obj == null)
            {
                return obj;
            }
            _context.Set<TEntity>().Remove(obj);
            return obj;
        }

        public async Task<IEnumerable<TEntity>> Get()
        {
            var res= await _context.Set<TEntity>().ToListAsync();
            return res;
        }

        public async Task<TEntity> GetById(int id)
        {
            return await _context.Set<TEntity>().FindAsync(id);
        }

        public async Task<TEntity> GetByName(Func<TEntity, bool> name)
        {
            return  _context.Set<TEntity>().AsNoTracking().Where(name).FirstOrDefault();
                
        }


        public async Task<TEntity> Update(TEntity obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            return obj;
        }

    }
}
