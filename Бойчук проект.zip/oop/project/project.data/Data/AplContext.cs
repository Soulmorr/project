﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using project.data.Models;
using project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class AplContext: IdentityDbContext<Users>
    {
        public AplContext()
        {
            
            Database.EnsureCreated();
        }


        public DbSet<Disciplines> Discplines { get; set; }
        public DbSet<Sponsors> Sponsors { get; set; }
        public DbSet<Users> User { get; set; }
        public DbSet<Table> Table { get; set; }
        public DbSet<Teams> Teams { get; set; }
        public DbSet<tournamenst> tournamenst { get; set; }

        public AplContext(DbContextOptions options) : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Disciplines>(End =>
            {
                End.HasKey(t => t.DisId);
                End.Property(t => t.DisName).HasMaxLength(30);

                

            });

            modelBuilder.Entity<Sponsors>(End =>
            {
                End.HasKey(sp => sp.SponsorID);
                End.Property(sp => sp.SponsorName).HasMaxLength(30);
                End.Property(st => st.tournamentid).HasMaxLength(30);
                End.Property(st => st.DonationAmount).HasMaxLength(30);
            });
            modelBuilder.Entity<Teams>(End =>
            {
                End.HasKey(sp => sp.TeamID);
                End.Property(sp => sp.TeamName).HasMaxLength(30);

            });

            modelBuilder.Entity<tournamenst>(End =>
            {
                End.HasKey(sp => sp.TournamentID);
                End.Property(sp => sp.TournamentName).HasMaxLength(30);

            });

            modelBuilder.Entity<User>(End =>
            {
                End.HasKey(st => st.ClientID);
                End.Property(st => st.Login).HasMaxLength(30);
                End.Property(st => st.Password).HasMaxLength(30);
                End.Property(st => st.Name).HasMaxLength(30);
                End.Property(st => st.Surname).HasMaxLength(30);
                End.Property(st => st.IsAuthenticated).HasMaxLength(30).IsRequired();
               
                //End.HasOne(st => st.teams).WithMany(sp => sp.user).HasForeignKey(t => t.Team);
            });

            modelBuilder.Entity<Table>(End =>
            {
                End.HasKey(cou => cou.turnamentsID);
                End.Property(cou => cou.dateandtimeofstart).HasColumnType("date").IsRequired();
                End.Property(cou => cou.dateandtimeofend).HasColumnType("date").IsRequired();
                End.Property(cou => cou.winningprize);
                End.HasMany(sp => sp.sponsors).WithMany(s => s.table).UsingEntity(j => j.ToTable("TableSponsors"));
                End.HasOne(cou => cou.discipline).WithMany(t => t.table).HasForeignKey(t => t.dispnameid);
            });
            Guid ADMIN_ID = Guid.NewGuid();
            Guid ROLE_ID = Guid.NewGuid();
            Users appUser = new Users
            {
                Id = ADMIN_ID.ToString(),
                UserName = "tester",
                Email = "tester@test.com",
                NormalizedEmail = "tester@test.com".ToUpper(),
                NormalizedUserName = "tester".ToUpper(),
                
            };

            PasswordHasher<Users> ph = new PasswordHasher<Users>();
            appUser.PasswordHash = ph.HashPassword(appUser, "Your-PW1");

            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole { Id = ROLE_ID.ToString(), Name = "Admin", NormalizedName = "ADMIN" },
                new IdentityRole { Name = "Member", NormalizedName = "MEMBER" }
               
            );
            modelBuilder.Entity<Users>().HasData(
                appUser
            );

            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string>
                {
                    RoleId = ROLE_ID.ToString(),
                    UserId = ADMIN_ID.ToString()
                }
                );
        }
    }
}
