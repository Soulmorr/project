﻿using project.data.Interfaces;
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class SponsorsRep : BaseRepository<Sponsors>, ISponsorsRep
    {
        public SponsorsRep(AplContext context) : base(context)
        {
        }
    }
}
