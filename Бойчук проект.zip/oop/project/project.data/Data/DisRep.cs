﻿using project.data.Interfaces;
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class DisRep : BaseRepository<Disciplines>, IDisRep
    {
        public DisRep(AplContext context) : base(context)
        {
        }
    }
}
