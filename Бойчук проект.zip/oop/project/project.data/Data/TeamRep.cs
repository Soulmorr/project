﻿using project.data.Interfaces;
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class TeamRep : BaseRepository<Teams>, ITeamsRep
    {
        public TeamRep(AplContext context) : base(context)
        {
        }
    }
}
