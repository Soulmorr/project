﻿using project.data.Interfaces;
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AplContext aplContext;
        public UnitOfWork(AplContext aplContext, ITableRep table, IUserRep user,ITournamentRep tournament,IDisRep dis,ISponsorsRep sponsors,ITeamsRep teams)
        {
            this.aplContext = aplContext;
            
            Table = table;
            Users = user;
            Tournament = tournament;
            Team = teams;
            Sponsor = sponsors;
            Dis = dis;
        }
    
        public ITableRep Table { get; }
        public IUserRep Users { get; }
        public ITournamentRep Tournament { get; }
        public IDisRep Dis { get; }
        public ISponsorsRep Sponsor { get; }
        public ITeamsRep Team { get; }
        public Task<int> Complete() => aplContext.SaveChangesAsync();
    }
}
