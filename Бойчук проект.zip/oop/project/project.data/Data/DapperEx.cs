﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using project.data.Interfaces;
using project.Models;
using System.Data.SqlClient;
using Dapper;
using project.data.Models;

namespace project.data.Data
{
    class DapperEx
    {
        public async Task<List<Table>> GetAllB()
        {
            string SQLRequest = "SELECT * FROM Student;";
            var Table = new List<Table>();
            using (var connection = new SqlConnection("Server=WIN-MHC1TDCCTHU\\SQLEXPRESS;Database=Tournamet2;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                return (List<Table>)connection.Query<Table>(SQLRequest);
            }
        }
    }
}
        
