﻿using project.data.Interfaces;
using project.data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project.data.Data
{
    public class TournamentRep : BaseRepository<tournamenst>, ITournamentRep
    {
        public TournamentRep(AplContext context) : base(context)
        {
        }
    }
}
