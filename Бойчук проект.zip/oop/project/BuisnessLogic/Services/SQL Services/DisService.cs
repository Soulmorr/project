﻿using AutoMapper;
using project.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using project.Models;
using Microsoft.AspNetCore.Mvc;

using BuisnessLogic.DTO;
using project.data.Interfaces;
using project.data.Models;

namespace project.BuisnessLogic.Services
{
    public class DisService : IDisService
    {
        private readonly IUnitOfWork _uof;
        protected IMapper _mapper;
        public DisService(IUnitOfWork uof, IMapper mapper)
        {
            _uof = uof;
            _mapper = mapper;

        }

        public async Task<Disciplines> AddTable(DisDTO obj)
        {
            Disciplines loc = _mapper.Map<DisDTO, Disciplines>(obj);
            var res = await _uof.Dis.Add(loc);
            await _uof.Complete();
            return res;
        }

        public async Task<Disciplines> DeleteTable(int id)
        {
            var res = await _uof.Dis.Delete(id);
            await _uof.Complete();
            return res;
        }
        public async Task<DisDTO> GetTableByID(int? id)
        {
            var res = _mapper.Map<Disciplines, DisDTO>(await _uof.Dis.GetById(id.Value));
            return res;
        }
        public async Task<IEnumerable<DisDTO>> GetAll()
        {
            var res = _mapper.Map<IEnumerable<Disciplines>, IEnumerable<DisDTO>>(await _uof.Dis.Get());
            return res;
        }

        public async Task<DisDTO> UpdateTable(DisDTO obj)
        {
            Disciplines location = _mapper.Map<Disciplines>(obj);
            var res = _mapper.Map<Disciplines, DisDTO>(await _uof.Dis.Update(location));
            await _uof.Complete();
            return res;

        }
    }
}
