﻿using AutoMapper;
using project.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using project.Models;
using Microsoft.AspNetCore.Mvc;

using BuisnessLogic.DTO;
using project.data.Interfaces;
using project.data.Models;

namespace project.BuisnessLogic.Services
{
    public class tableService : ITableService
    {
        private readonly IUnitOfWork _uof;
        protected IMapper _mapper;
        public tableService(IUnitOfWork uof, IMapper mapper)
        {
            _uof = uof;
            _mapper = mapper;

        }

        public async Task<Table> AddTable(TableDTO obj)
        {
            Table loc = _mapper.Map<TableDTO, Table>(obj);
            var res = await _uof.Table.Add(loc);
            await _uof.Complete();
            return res;
        }

        public async Task<Table> DeleteTable(int id)
        {
            var res = await _uof.Table.Delete(id);
            await _uof.Complete();
            return res;
        }
        public async Task<TableDTO> GetTableByID(int? id)
        {
            var res = _mapper.Map<Table, TableDTO>(await _uof.Table.GetById(id.Value));
            return res;
        }
        public async Task<IEnumerable<TableDTO>> GetAll()
        {
            var res = _mapper.Map<IEnumerable<Table>, IEnumerable<TableDTO>>(await _uof.Table.Get());
            return res;
        }

        public async Task<TableDTO> UpdateTable(TableDTO obj)
        {
            Table location = _mapper.Map<Table>(obj);
            var res = _mapper.Map<Table, TableDTO>(await _uof.Table.Update(location));
            await _uof.Complete();
            return res;

        }
    }
}
