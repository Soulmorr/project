﻿
using project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BuisnessLogic.DTO;
using project.data.Models;

namespace project.Interfaces
{
  
    public interface ITableService
    {
        Task<TableDTO> UpdateTable(TableDTO obj);// update courses
        Task<TableDTO> GetTableByID(int? id);// return courses by courses id
        Task<Table> DeleteTable(int id);// delete courses by courses id
        Task<Table> AddTable(TableDTO obj);
        Task<IEnumerable<TableDTO>> GetAll();

    }
}
