﻿
using project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BuisnessLogic.DTO;
using project.data.Models;

namespace project.Interfaces
{
  
    public interface IDisService
    {
        Task<DisDTO> UpdateTable(DisDTO obj);// update courses
        Task<DisDTO> GetTableByID(int? id);// return courses by courses id
        Task<Disciplines> DeleteTable(int id);// delete courses by courses id
        Task<Disciplines> AddTable(DisDTO obj);
        Task<IEnumerable<DisDTO>> GetAll();

    }
}
