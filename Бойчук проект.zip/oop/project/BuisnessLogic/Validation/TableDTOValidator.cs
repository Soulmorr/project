﻿using FluentValidation;
using BuisnessLogic.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace project.BuisnessLogic.Validators
{
    public class TableDTOValidator : AbstractValidator<TableDTO>
    {
        public TableDTOValidator()
        {
            RuleFor(e => e.turnamentsID)
            .NotEmpty().WithMessage("Name cann`t be empty");

            RuleFor(e => e.dispnameid)
          .NotEmpty().WithMessage("Name cann`t be empty");

            RuleFor(e => e.discipline)
                .NotEmpty().WithMessage("discipline cann`t be null");

            RuleFor(x => x.dateandtimeofstart)
                .NotNull()
                .NotEmpty().WithMessage("date and time of start cann`t be empty")
                .GreaterThan(DateTime.Now.AddDays(1)).WithMessage("date and time of start must will later");

            RuleFor(x => x.dateandtimeofend)
             .NotNull()
             .NotEmpty().WithMessage("date and time of end cann`t be empty")
             .GreaterThan(DateTime.Now.AddDays(1)).WithMessage("date and time of end must will later");

            RuleFor(e => e.sponsors)
                .NotEmpty().WithMessage("sponsors cann`t be null");

            RuleFor(e => e.winningprize)
                .NotEmpty().WithMessage("winning prize cann`t be empty");
                
        }

    }
}
