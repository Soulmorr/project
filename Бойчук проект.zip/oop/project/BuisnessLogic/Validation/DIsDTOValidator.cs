﻿using FluentValidation;
using BuisnessLogic.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace project.BuisnessLogic.Validators
{
    public class DIsDTOValidator : AbstractValidator<DisDTO>
    {
        public DIsDTOValidator()
        {
            RuleFor(e => e.DisId)
            .NotEmpty().WithMessage("Name cann`t be empty");

            RuleFor(e => e.DisName)
          .NotEmpty().WithMessage("Name cann`t be empty");

        }

    }
}
