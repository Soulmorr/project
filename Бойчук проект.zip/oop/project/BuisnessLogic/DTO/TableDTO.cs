﻿using System;
using System.Collections.Generic;
using System.Text;
using project.data.Models;
namespace BuisnessLogic.DTO
{
    public class TableDTO
    {
        public int turnamentsID { get; set; }
        public int dispnameid { get; set; }
        public DateTime dateandtimeofstart { get; set; }

        public DateTime dateandtimeofend { get; set; }
        public int winningprize { get; set; }
        public List<Sponsors> sponsors { get; set; }
        public Teams discipline { get; set; }
    }
}
