﻿using System;
using System.Collections.Generic;
using System.Text;
using project.data.Models;
namespace BuisnessLogic.DTO
{
    public class DisDTO
    {
        public int DisId { get; set; }
        public string DisName { get; set; }
    }
}
