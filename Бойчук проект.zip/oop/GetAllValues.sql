USE Tournamet;
GO
CREATE PROCEDURE GetAllValues AS
SELECT * 
FROM Discplines